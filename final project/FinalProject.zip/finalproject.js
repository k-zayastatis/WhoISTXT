
document.getElementById('youtube-button').addEventListener('click', function() {
    // Replace the link below with the actual YouTube channel URL
    window.location.href = 'https://www.youtube.com/@TXT_bighit';
  });
